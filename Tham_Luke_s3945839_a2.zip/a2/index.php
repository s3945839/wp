<?php
 include ("includes/header.inc");?>
        <main class="index-page-main">
            <div class="main-title">
                <h1>Pets Victoria</h1>
                <h2>Welcome To Pet Adoption</h2>
            </div>
            <div class="main-image">
                <img src="main.jpg" alt="main">
            </div>
        </main>
        <?php
 include ("includes/footer.inc");?>